import EventEmitter from "./event-emitter";
export default new EventEmitter();
//# sourceMappingURL=dispatcher.js.map
