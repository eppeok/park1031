export default () => Math.round(performance.now()) / 1e3;
//# sourceMappingURL=delta.js.map
