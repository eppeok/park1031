<?php

namespace YoastSEO_Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \YoastSEO_Vendor\GuzzleHttp\Exception\GuzzleException
{
}
